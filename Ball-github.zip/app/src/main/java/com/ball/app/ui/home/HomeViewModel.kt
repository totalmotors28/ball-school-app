package com.ball.app.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ball.app.BallApp
import com.ball.app.domain.Calc
import com.ball.app.domain.GoalItem
import com.ball.app.domain.SubjectStat
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

data class HomeUiState(
    val average: Double? = null,
    val trend: Double = 0.0,
    val streak: Int = 0,
    val goal: GoalItem? = null,
    val weakest: SubjectStat? = null,
    val forecast: Double? = null
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = (application as BallApp).repository

    val state: StateFlow<HomeUiState> = combine(
        repo.grades, repo.subjects, repo.goals, repo.streak
    ) { grades, subjects, goals, streak ->
        val today = LocalDate.now().toEpochDay()
        val stats = Calc.subjectStats(subjects, grades)
        val goalItems = Calc.goalItems(goals, subjects, grades)
        HomeUiState(
            average = Calc.average(grades),
            trend = Calc.trend(grades, today),
            streak = Calc.effectiveStreak(streak, today),
            goal = goalItems.filter { it.progress < 100 }.maxByOrNull { it.progress }
                ?: goalItems.firstOrNull(),
            weakest = stats.filter { it.average != null }.minByOrNull { it.average ?: Double.MAX_VALUE },
            forecast = Calc.forecast(grades, today)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())
}
