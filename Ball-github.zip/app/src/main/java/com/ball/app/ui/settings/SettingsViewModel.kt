package com.ball.app.ui.settings

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ball.app.BallApp
import com.ball.app.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class SettingsUiState(
    val name: String = "",
    val grade: String = "",
    /** String resource id of a one-shot message to show, or null. */
    val message: Int? = null
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = (application as BallApp).repository

    private val _state = MutableStateFlow(
        repo.getProfile().let { (name, grade) -> SettingsUiState(name = name, grade = grade) }
    )
    val state: StateFlow<SettingsUiState> = _state

    fun onNameChange(value: String) = _state.update { it.copy(name = value) }
    fun onGradeChange(value: String) = _state.update { it.copy(grade = value) }

    fun saveProfile() {
        val s = _state.value
        repo.saveProfile(s.name, s.grade)
        _state.update { it.copy(message = R.string.settings_saved) }
    }

    fun consumeMessage() = _state.update { it.copy(message = null) }

    fun exportTo(uri: Uri) {
        viewModelScope.launch {
            val result = runCatching {
                val json = repo.exportJson()
                withContext(Dispatchers.IO) {
                    val stream = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                        ?: error("Cannot open output stream")
                    stream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                }
            }
            _state.update {
                it.copy(
                    message = if (result.isSuccess) R.string.settings_export_done
                    else R.string.settings_export_error
                )
            }
        }
    }

    fun importFrom(uri: Uri) {
        viewModelScope.launch {
            val result = runCatching {
                val text = withContext(Dispatchers.IO) {
                    val stream = getApplication<Application>().contentResolver.openInputStream(uri)
                        ?: error("Cannot open input stream")
                    stream.use { String(it.readBytes(), Charsets.UTF_8) }
                }
                repo.importJson(text)
            }
            val (name, grade) = repo.getProfile()
            _state.update {
                it.copy(
                    name = name,
                    grade = grade,
                    message = if (result.isSuccess) R.string.settings_import_done
                    else R.string.settings_import_error
                )
            }
        }
    }

    fun clearAll() {
        viewModelScope.launch {
            repo.clearAll()
            _state.update { SettingsUiState(message = R.string.settings_cleared) }
        }
    }
}
