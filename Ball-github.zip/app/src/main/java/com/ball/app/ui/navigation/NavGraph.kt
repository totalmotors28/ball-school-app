package com.ball.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.ball.app.R
import com.ball.app.ui.addgrade.AddGradeScreen
import com.ball.app.ui.goals.GoalsScreen
import com.ball.app.ui.home.HomeScreen
import com.ball.app.ui.settings.SettingsScreen
import com.ball.app.ui.stats.StatsScreen
import com.ball.app.ui.subjects.SubjectDetailScreen
import com.ball.app.ui.subjects.SubjectsScreen
import com.ball.app.ui.theme.Background
import com.ball.app.ui.theme.CardBg

object Routes {
    const val HOME = "home"
    const val SUBJECTS = "subjects"
    const val SUBJECT_DETAIL = "subject/{id}"
    const val ADD_GRADE = "add_grade"
    const val STATS = "stats"
    const val GOALS = "goals"
    const val SETTINGS = "settings"

    fun subject(id: Long) = "subject/$id"
}

private data class Tab(val route: String, val label: Int, val icon: ImageVector)

private val tabs = listOf(
    Tab(Routes.HOME, R.string.nav_home, Icons.Filled.Home),
    Tab(Routes.SUBJECTS, R.string.nav_subjects, Icons.Filled.Book),
    Tab(Routes.STATS, R.string.nav_stats, Icons.Filled.BarChart),
    Tab(Routes.GOALS, R.string.nav_goals, Icons.Filled.Flag)
)

@Composable
fun BallNavGraph() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route
    val showBottomBar = route != null && route != Routes.ADD_GRADE && route != Routes.SETTINGS

    Scaffold(
        containerColor = Background,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = CardBg) {
                    tabs.forEach { tab ->
                        val selected = route == tab.route ||
                            (tab.route == Routes.SUBJECTS && route == Routes.SUBJECT_DETAIL)
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = null) },
                            label = { Text(stringResource(tab.label), maxLines = 1) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    onAddGrade = { navController.navigate(Routes.ADD_GRADE) },
                    onOpenSettings = { navController.navigate(Routes.SETTINGS) }
                )
            }
            composable(Routes.SUBJECTS) {
                SubjectsScreen(onOpenSubject = { navController.navigate(Routes.subject(it)) })
            }
            composable(
                route = Routes.SUBJECT_DETAIL,
                arguments = listOf(navArgument("id") { type = NavType.LongType })
            ) { entry ->
                val id = entry.arguments?.getLong("id") ?: 0L
                SubjectDetailScreen(
                    subjectId = id,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.ADD_GRADE) {
                AddGradeScreen(onBack = { navController.popBackStack() })
            }
            composable(Routes.STATS) {
                StatsScreen()
            }
            composable(Routes.GOALS) {
                GoalsScreen()
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
