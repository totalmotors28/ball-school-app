package com.ball.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

object GradeKinds {
    const val HOMEWORK = "homework"
    const val TEST = "test"
    const val QUIZ = "quiz"
    val ALL = listOf(HOMEWORK, TEST, QUIZ)
}

/** [date] is stored as an epoch day (LocalDate.toEpochDay()), [createdAt] as epoch millis. */
@Entity(
    tableName = "grades",
    foreignKeys = [
        ForeignKey(
            entity = SubjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId")]
)
data class GradeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val subjectId: Long,
    val value: Int,
    val kind: String,
    val date: Long,
    val createdAt: Long
)
