package com.ball.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BallColorScheme = darkColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = TextPrimary,
    secondary = Green,
    onSecondary = Color(0xFF052E16),
    secondaryContainer = Color(0xFF1E3A5F),
    onSecondaryContainer = TextPrimary,
    background = Background,
    onBackground = TextPrimary,
    surface = Background,
    onSurface = TextPrimary,
    surfaceVariant = CardBg,
    onSurfaceVariant = TextMuted,
    surfaceContainer = CardBg,
    surfaceContainerLow = CardBg,
    surfaceContainerHigh = SurfaceHigh,
    surfaceContainerHighest = SurfaceHighest,
    outline = OutlineColor,
    outlineVariant = SurfaceHighest,
    error = Danger,
    onError = Color.White
)

/** Dark theme only; dynamic color is intentionally not used. */
@Composable
fun BallTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = BallColorScheme,
        typography = BallTypography,
        content = content
    )
}
