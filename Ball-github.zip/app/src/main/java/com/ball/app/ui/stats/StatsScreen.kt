package com.ball.app.ui.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ball.app.R
import com.ball.app.domain.SubjectStat
import com.ball.app.ui.common.BallCard
import com.ball.app.ui.common.ScreenHeader
import com.ball.app.ui.common.formatDate
import com.ball.app.ui.common.formatNumber
import com.ball.app.ui.common.gradeColor
import com.ball.app.ui.theme.Amber
import com.ball.app.ui.theme.Blue
import com.ball.app.ui.theme.Danger
import com.ball.app.ui.theme.Green
import com.ball.app.ui.theme.TextMuted
import java.util.Locale
import kotlin.math.min

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(viewModel: StatsViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        ScreenHeader(title = stringResource(R.string.stats_title))
        Spacer(Modifier.height(8.dp))

        val options = listOf(
            StatsPeriod.WEEK to R.string.stats_week,
            StatsPeriod.MONTH to R.string.stats_month,
            StatsPeriod.TERM to R.string.stats_term
        )
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            options.forEachIndexed { index, (period, label) ->
                SegmentedButton(
                    selected = state.period == period,
                    onClick = { viewModel.setPeriod(period) },
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = options.size)
                ) {
                    Text(text = stringResource(label), maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        if (state.total == 0) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.stats_no_data),
                    style = MaterialTheme.typography.titleMedium,
                    color = TextMuted
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Average + chart
                BallCard {
                    Text(
                        text = stringResource(R.string.stats_period_avg),
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextMuted
                    )
                    Text(
                        text = formatNumber(state.average),
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(12.dp))
                    BarChart(
                        values = state.buckets,
                        gridColor = MaterialTheme.colorScheme.outlineVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = formatDate(state.rangeStart),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = formatDate(state.rangeEnd),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted
                        )
                    }
                }

                // Distribution
                BallCard {
                    Text(
                        text = stringResource(R.string.stats_distribution),
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(10.dp))
                    for (value in 5 downTo 2) {
                        val count = state.distribution[value] ?: 0
                        val fraction = if (state.total == 0) 0f else count.toFloat() / state.total
                        val percent = (fraction * 100f).toInt()
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = value.toString(),
                                style = MaterialTheme.typography.titleLarge,
                                color = gradeColor(value.toDouble()),
                                modifier = Modifier.width(28.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(18.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                if (fraction > 0f) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .fillMaxWidth(fraction)
                                            .clip(RoundedCornerShape(9.dp))
                                            .background(gradeColor(value.toDouble()))
                                    )
                                }
                            }
                            Text(
                                text = String.format(Locale.getDefault(), "%d (%d%%)", count, percent),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextMuted,
                                modifier = Modifier.width(84.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                            )
                        }
                    }
                }

                // Best / worst
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SubjectHighlight(
                        label = stringResource(R.string.stats_best),
                        stat = state.best,
                        modifier = Modifier.weight(1f)
                    )
                    SubjectHighlight(
                        label = stringResource(R.string.stats_worst),
                        stat = state.worst,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun SubjectHighlight(label: String, stat: SubjectStat?, modifier: Modifier = Modifier) {
    BallCard(modifier = modifier) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
        Spacer(Modifier.height(4.dp))
        Text(
            text = stat?.subject?.name ?: "—",
            style = MaterialTheme.typography.titleMedium,
            maxLines = 2
        )
        Text(
            text = formatNumber(stat?.average),
            style = MaterialTheme.typography.titleLarge,
            color = stat?.average?.let { gradeColor(it) } ?: TextMuted
        )
    }
}

@Composable
private fun BarChart(values: List<Double?>, gridColor: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val count = values.size
        if (count == 0) return@Canvas
        val maxValue = 5f

        // Grid lines at 2, 3, 4, 5
        for (g in 2..5) {
            val y = size.height - size.height * (g / maxValue)
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        val gap = if (count > 14) 2.dp.toPx() else 6.dp.toPx()
        val barWidth = ((size.width - gap * (count - 1)) / count).coerceAtLeast(1f)
        val radius = min(4.dp.toPx(), barWidth / 2f)

        values.forEachIndexed { index, value ->
            if (value != null) {
                val barHeight = size.height * (value.toFloat() / maxValue)
                drawRoundRect(
                    color = gradeColor(value),
                    topLeft = Offset(index * (barWidth + gap), size.height - barHeight),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(radius, radius)
                )
            }
        }
    }
}
