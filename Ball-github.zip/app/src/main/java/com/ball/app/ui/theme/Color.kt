package com.ball.app.ui.theme

import androidx.compose.ui.graphics.Color

val Blue = Color(0xFF3B82F6)
val Green = Color(0xFF22C55E)
val Background = Color(0xFF0F1115)
val CardBg = Color(0xFF1A1D23)
val TextPrimary = Color(0xFFE5E7EB)
val TextMuted = Color(0xFF9CA3AF)
val Danger = Color(0xFFEF4444)
val Amber = Color(0xFFF59E0B)
val OutlineColor = Color(0xFF374151)
val SurfaceHigh = Color(0xFF22262E)
val SurfaceHighest = Color(0xFF2A2F38)
