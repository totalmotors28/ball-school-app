package com.ball.app.ui.stats

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ball.app.BallApp
import com.ball.app.domain.Calc
import com.ball.app.domain.SubjectStat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

enum class StatsPeriod(val days: Int) {
    WEEK(7),
    MONTH(30),
    TERM(90)
}

data class StatsUiState(
    val period: StatsPeriod = StatsPeriod.WEEK,
    val average: Double? = null,
    /** Bars of the chart: average per bucket (day, or week for the term), null = no grades. */
    val buckets: List<Double?> = emptyList(),
    val rangeStart: Long = 0L,
    val rangeEnd: Long = 0L,
    /** grade value (2..5) -> count */
    val distribution: Map<Int, Int> = emptyMap(),
    val total: Int = 0,
    val best: SubjectStat? = null,
    val worst: SubjectStat? = null
)

class StatsViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = (application as BallApp).repository
    private val period = MutableStateFlow(StatsPeriod.WEEK)

    val state: StateFlow<StatsUiState> = combine(repo.grades, repo.subjects, period) { grades, subjects, p ->
        val today = LocalDate.now().toEpochDay()
        val start = today - (p.days - 1)
        val inRange = grades.filter { it.date in start..today }

        val bucketSize = if (p == StatsPeriod.TERM) 7 else 1
        val bucketCount = (p.days + bucketSize - 1) / bucketSize
        val sums = DoubleArray(bucketCount)
        val counts = IntArray(bucketCount)
        inRange.forEach {
            val index = ((it.date - start) / bucketSize).toInt().coerceIn(0, bucketCount - 1)
            sums[index] += it.value.toDouble()
            counts[index]++
        }
        val buckets = List(bucketCount) { i -> if (counts[i] == 0) null else sums[i] / counts[i] }

        val distribution = (2..5).associateWith { v -> inRange.count { it.value == v } }
        val stats = Calc.subjectStats(subjects, inRange).filter { it.count > 0 }

        StatsUiState(
            period = p,
            average = Calc.average(inRange),
            buckets = buckets,
            rangeStart = start,
            rangeEnd = today,
            distribution = distribution,
            total = inRange.size,
            best = stats.maxByOrNull { it.average ?: 0.0 },
            worst = stats.minByOrNull { it.average ?: 0.0 }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatsUiState())

    fun setPeriod(value: StatsPeriod) {
        period.value = value
    }
}
