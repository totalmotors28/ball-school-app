package com.ball.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Single-row table: id is always 1. [lastEntryDate] is an epoch day. */
@Entity(tableName = "streak")
data class StreakEntity(
    @PrimaryKey val id: Int = 1,
    val lastEntryDate: Long,
    val count: Int
)
