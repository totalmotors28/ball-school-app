package com.ball.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ball.app.R
import com.ball.app.ui.common.BallCard
import com.ball.app.ui.common.formatNumber
import com.ball.app.ui.common.gradeColor
import com.ball.app.ui.common.pluralString
import com.ball.app.ui.theme.Danger
import com.ball.app.ui.theme.Green
import com.ball.app.ui.theme.TextMuted
import kotlin.math.abs

@Composable
fun HomeScreen(
    onAddGrade: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = stringResource(R.string.nav_settings)
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Average + trend + streak
            BallCard {
                Text(
                    text = stringResource(R.string.home_average),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextMuted
                )
                Text(
                    text = formatNumber(state.average),
                    fontSize = 56.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                if (state.average == null) {
                    Text(
                        text = stringResource(R.string.home_no_data),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                }
                Spacer(Modifier.height(8.dp))

                val trend = state.trend
                val arrow: String
                val trendText: String
                val trendColor = when {
                    trend >= 0.005 -> {
                        arrow = "↑"
                        trendText = "+" + formatNumber(trend)
                        Green
                    }
                    trend <= -0.005 -> {
                        arrow = "↓"
                        trendText = "−" + formatNumber(abs(trend))
                        Danger
                    }
                    else -> {
                        arrow = "→"
                        trendText = formatNumber(0.0)
                        TextMuted
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.home_trend),
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextMuted,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "$arrow $trendText",
                        style = MaterialTheme.typography.titleLarge,
                        color = trendColor
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = pluralString(R.plurals.home_streak, state.streak),
                    style = MaterialTheme.typography.titleMedium
                )
            }

            // Nearest goal
            BallCard {
                Text(
                    text = stringResource(R.string.home_nearest_goal),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextMuted
                )
                val goal = state.goal
                if (goal == null) {
                    Text(
                        text = stringResource(R.string.goals_empty),
                        style = MaterialTheme.typography.bodyLarge
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = goal.subjectName,
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = stringResource(
                                R.string.goals_target,
                                formatNumber(goal.goal.target, 1)
                            ),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { goal.progress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.outlineVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.goals_progress, goal.progress),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                }
            }

            // Weakest subject
            BallCard {
                Text(
                    text = stringResource(R.string.home_weakest),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextMuted
                )
                val weakest = state.weakest
                if (weakest == null) {
                    Text(
                        text = stringResource(R.string.home_no_data),
                        style = MaterialTheme.typography.bodyLarge
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = weakest.subject.name,
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = formatNumber(weakest.average),
                            style = MaterialTheme.typography.titleLarge,
                            color = gradeColor(weakest.average ?: 0.0)
                        )
                    }
                }
            }

            // Forecast
            BallCard {
                Text(
                    text = stringResource(R.string.home_forecast),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextMuted
                )
                Text(
                    text = formatNumber(state.forecast),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onAddGrade,
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
        ) {
            Text(
                text = stringResource(R.string.home_add_grade),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
