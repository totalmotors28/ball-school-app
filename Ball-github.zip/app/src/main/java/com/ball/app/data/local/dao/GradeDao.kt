package com.ball.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.ball.app.data.local.entity.GradeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GradeDao {
    @Query("SELECT * FROM grades ORDER BY date DESC, createdAt DESC")
    fun getAll(): Flow<List<GradeEntity>>

    @Query("SELECT * FROM grades ORDER BY id ASC")
    suspend fun getAllList(): List<GradeEntity>

    @Query("SELECT * FROM grades WHERE subjectId = :subjectId ORDER BY date DESC, createdAt DESC")
    fun getBySubject(subjectId: Long): Flow<List<GradeEntity>>

    @Query("SELECT AVG(value) FROM grades")
    suspend fun averageAll(): Double?

    @Query("SELECT AVG(value) FROM grades WHERE subjectId = :id")
    suspend fun averageForSubject(id: Long): Double?

    @Query("SELECT AVG(value) FROM grades WHERE date BETWEEN :from AND :to")
    suspend fun averageBetween(from: Long, to: Long): Double?

    @Query("SELECT COUNT(*) FROM grades WHERE subjectId = :id")
    suspend fun countForSubject(id: Long): Int

    @Insert
    suspend fun insert(grade: GradeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(grades: List<GradeEntity>)

    @Delete
    suspend fun delete(grade: GradeEntity)

    @Query("DELETE FROM grades")
    suspend fun deleteAll()
}
