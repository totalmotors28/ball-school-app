package com.ball.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.ball.app.data.local.dao.GoalDao
import com.ball.app.data.local.dao.GradeDao
import com.ball.app.data.local.dao.StreakDao
import com.ball.app.data.local.dao.SubjectDao
import com.ball.app.data.local.entity.GoalEntity
import com.ball.app.data.local.entity.GradeEntity
import com.ball.app.data.local.entity.StreakEntity
import com.ball.app.data.local.entity.SubjectEntity

@Database(
    entities = [
        SubjectEntity::class,
        GradeEntity::class,
        GoalEntity::class,
        StreakEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun gradeDao(): GradeDao
    abstract fun goalDao(): GoalDao
    abstract fun streakDao(): StreakDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ball.db"
                ).build().also { instance = it }
            }
    }
}
