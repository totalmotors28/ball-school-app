package com.ball.app.data.prefs

import android.content.Context

/** Student profile (name and class) stored in SharedPreferences. */
class ProfilePrefs(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("profile", Context.MODE_PRIVATE)

    var name: String
        get() = prefs.getString(KEY_NAME, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_NAME, value).apply()
        }

    var grade: String
        get() = prefs.getString(KEY_GRADE, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_GRADE, value).apply()
        }

    fun clear() {
        prefs.edit().clear().apply()
    }

    private companion object {
        const val KEY_NAME = "name"
        const val KEY_GRADE = "grade"
    }
}
