package com.ball.app.data.repository

import androidx.room.withTransaction
import com.ball.app.data.local.AppDatabase
import com.ball.app.data.local.entity.GoalEntity
import com.ball.app.data.local.entity.GradeEntity
import com.ball.app.data.local.entity.GradeKinds
import com.ball.app.data.local.entity.StreakEntity
import com.ball.app.data.local.entity.SubjectEntity
import com.ball.app.data.prefs.ProfilePrefs
import com.ball.app.domain.Calc
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class BallRepository(
    private val db: AppDatabase,
    private val profile: ProfilePrefs
) {
    private val subjectDao = db.subjectDao()
    private val gradeDao = db.gradeDao()
    private val goalDao = db.goalDao()
    private val streakDao = db.streakDao()

    val subjects: Flow<List<SubjectEntity>> = subjectDao.getAll()
    val grades: Flow<List<GradeEntity>> = gradeDao.getAll()
    val goals: Flow<List<GoalEntity>> = goalDao.getAll()
    val streak: Flow<StreakEntity?> = streakDao.getFlow()

    fun subject(id: Long): Flow<SubjectEntity?> = subjectDao.getById(id)
    fun gradesBySubject(id: Long): Flow<List<GradeEntity>> = gradeDao.getBySubject(id)

    suspend fun addSubject(name: String) {
        subjectDao.insert(SubjectEntity(name = name.trim(), createdAt = System.currentTimeMillis()))
    }

    suspend fun deleteSubject(subject: SubjectEntity) = subjectDao.delete(subject)

    /** Inserts the grade and updates the streak in a single transaction. */
    suspend fun addGrade(subjectId: Long, value: Int, kind: String, epochDay: Long) {
        db.withTransaction {
            gradeDao.insert(
                GradeEntity(
                    subjectId = subjectId,
                    value = value,
                    kind = kind,
                    date = epochDay,
                    createdAt = System.currentTimeMillis()
                )
            )
            val today = LocalDate.now().toEpochDay()
            streakDao.upsert(Calc.streakNext(streakDao.get(), today))
        }
    }

    suspend fun deleteGrade(grade: GradeEntity) = gradeDao.delete(grade)

    suspend fun addGoal(subjectId: Long, target: Double) {
        val start = gradeDao.averageForSubject(subjectId) ?: 0.0
        goalDao.insert(
            GoalEntity(
                subjectId = subjectId,
                target = target,
                startAverage = start,
                deadline = null,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteGoal(goal: GoalEntity) = goalDao.delete(goal)

    fun getProfile(): Pair<String, String> = profile.name to profile.grade

    fun saveProfile(name: String, grade: String) {
        profile.name = name.trim()
        profile.grade = grade.trim()
    }

    suspend fun clearAll() {
        db.withTransaction {
            gradeDao.deleteAll()
            goalDao.deleteAll()
            subjectDao.deleteAll()
            streakDao.deleteAll()
        }
        profile.clear()
    }

    suspend fun exportJson(): String {
        val subjects = subjectDao.getAllList()
        val grades = gradeDao.getAllList()
        val goals = goalDao.getAllList()
        val streak = streakDao.get()

        val root = JSONObject()
        root.put("version", 1)
        root.put(
            "profile",
            JSONObject().put("name", profile.name).put("grade", profile.grade)
        )
        root.put("subjects", JSONArray().also { arr ->
            subjects.forEach {
                arr.put(
                    JSONObject()
                        .put("id", it.id)
                        .put("name", it.name)
                        .put("createdAt", it.createdAt)
                )
            }
        })
        root.put("grades", JSONArray().also { arr ->
            grades.forEach {
                arr.put(
                    JSONObject()
                        .put("id", it.id)
                        .put("subjectId", it.subjectId)
                        .put("value", it.value)
                        .put("kind", it.kind)
                        .put("date", it.date)
                        .put("createdAt", it.createdAt)
                )
            }
        })
        root.put("goals", JSONArray().also { arr ->
            goals.forEach {
                arr.put(
                    JSONObject()
                        .put("id", it.id)
                        .put("subjectId", it.subjectId)
                        .put("target", it.target)
                        .put("startAverage", it.startAverage)
                        .put("deadline", it.deadline ?: JSONObject.NULL)
                        .put("createdAt", it.createdAt)
                )
            }
        })
        if (streak != null) {
            root.put(
                "streak",
                JSONObject()
                    .put("lastEntryDate", streak.lastEntryDate)
                    .put("count", streak.count)
            )
        }
        return root.toString(2)
    }

    /**
     * Replaces all data with the contents of the JSON backup.
     * The file is fully parsed before anything is deleted, so an invalid file changes nothing.
     * Throws on invalid input.
     */
    suspend fun importJson(text: String) {
        val root = JSONObject(text)

        val subjects = root.getJSONArray("subjects").objects().map {
            SubjectEntity(
                id = it.getLong("id"),
                name = it.getString("name"),
                createdAt = it.getLong("createdAt")
            )
        }
        val subjectIds = subjects.map { it.id }.toSet()

        val grades = root.optJSONArray("grades")?.objects().orEmpty().map {
            GradeEntity(
                id = it.getLong("id"),
                subjectId = it.getLong("subjectId"),
                value = it.getInt("value"),
                kind = it.getString("kind"),
                date = it.getLong("date"),
                createdAt = it.getLong("createdAt")
            )
        }.filter { it.subjectId in subjectIds && it.value in 2..5 && it.kind in GradeKinds.ALL }

        val goals = root.optJSONArray("goals")?.objects().orEmpty().map {
            GoalEntity(
                id = it.getLong("id"),
                subjectId = it.getLong("subjectId"),
                target = it.getDouble("target"),
                startAverage = it.getDouble("startAverage"),
                deadline = if (it.isNull("deadline")) null else it.getLong("deadline"),
                createdAt = it.getLong("createdAt")
            )
        }.filter { it.subjectId in subjectIds }

        val streak = root.optJSONObject("streak")?.let {
            StreakEntity(
                id = 1,
                lastEntryDate = it.getLong("lastEntryDate"),
                count = it.getInt("count")
            )
        }

        db.withTransaction {
            gradeDao.deleteAll()
            goalDao.deleteAll()
            subjectDao.deleteAll()
            streakDao.deleteAll()
            subjectDao.insertAll(subjects)
            gradeDao.insertAll(grades)
            goalDao.insertAll(goals)
            if (streak != null) streakDao.upsert(streak)
        }

        root.optJSONObject("profile")?.let {
            profile.name = it.optString("name", "")
            profile.grade = it.optString("grade", "")
        }
    }

    private fun JSONArray.objects(): List<JSONObject> = List(length()) { getJSONObject(it) }
}
