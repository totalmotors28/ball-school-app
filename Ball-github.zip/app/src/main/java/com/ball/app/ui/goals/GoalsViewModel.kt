package com.ball.app.ui.goals

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ball.app.BallApp
import com.ball.app.data.local.entity.GoalEntity
import com.ball.app.data.local.entity.SubjectEntity
import com.ball.app.domain.Calc
import com.ball.app.domain.GoalItem
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class GoalsUiState(
    val items: List<GoalItem> = emptyList(),
    val subjects: List<SubjectEntity> = emptyList()
)

class GoalsViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = (application as BallApp).repository

    val state: StateFlow<GoalsUiState> = combine(repo.goals, repo.subjects, repo.grades) { goals, subjects, grades ->
        GoalsUiState(Calc.goalItems(goals, subjects, grades), subjects)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GoalsUiState())

    fun addGoal(subjectId: Long, target: Double) {
        viewModelScope.launch { repo.addGoal(subjectId, target) }
    }

    fun deleteGoal(goal: GoalEntity) {
        viewModelScope.launch { repo.deleteGoal(goal) }
    }
}
