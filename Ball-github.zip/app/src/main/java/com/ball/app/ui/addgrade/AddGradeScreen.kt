package com.ball.app.ui.addgrade

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ball.app.R
import com.ball.app.data.local.entity.GradeKinds
import com.ball.app.ui.common.ScreenHeader
import com.ball.app.ui.common.formatDate
import com.ball.app.ui.theme.CardBg
import com.ball.app.ui.theme.SurfaceHigh
import com.ball.app.ui.theme.TextMuted
import java.time.LocalDate

private const val DAY_MS = 86_400_000L

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddGradeScreen(
    onBack: () -> Unit,
    viewModel: AddGradeViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var showPicker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        ScreenHeader(title = stringResource(R.string.add_title), onBack = onBack)
        Spacer(Modifier.height(8.dp))

        if (state.subjects.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.add_need_subject),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextMuted
                )
            }
            OutlinedButton(
                onClick = onBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(stringResource(R.string.add_cancel))
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Subject
                Text(
                    text = stringResource(R.string.add_subject),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextMuted
                )
                state.subjects.forEach { subject ->
                    val selected = subject.id == state.subjectId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) SurfaceHigh else CardBg)
                            .clickable { viewModel.selectSubject(subject.id) }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selected,
                            onClick = { viewModel.selectSubject(subject.id) }
                        )
                        Text(
                            text = subject.name,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }

                // Value
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.add_value),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextMuted
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    listOf(2, 3, 4, 5).forEach { v ->
                        val modifier = Modifier
                            .weight(1f)
                            .height(72.dp)
                        if (state.value == v) {
                            Button(
                                onClick = { viewModel.selectValue(v) },
                                modifier = modifier,
                                shape = RoundedCornerShape(16.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(v.toString(), fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            OutlinedButton(
                                onClick = { viewModel.selectValue(v) },
                                modifier = modifier,
                                shape = RoundedCornerShape(16.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(v.toString(), fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Kind
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.add_kind),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextMuted
                )
                val kinds = listOf(
                    GradeKinds.HOMEWORK to R.string.add_kind_homework,
                    GradeKinds.TEST to R.string.add_kind_test,
                    GradeKinds.QUIZ to R.string.add_kind_quiz
                )
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    kinds.forEachIndexed { index, (kind, label) ->
                        SegmentedButton(
                            selected = state.kind == kind,
                            onClick = { viewModel.selectKind(kind) },
                            shape = SegmentedButtonDefaults.itemShape(index = index, count = kinds.size),
                            icon = {}
                        ) {
                            Text(text = stringResource(label), maxLines = 1, fontSize = 13.sp)
                        }
                    }
                }

                // Date
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.add_date),
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextMuted
                )
                OutlinedButton(
                    onClick = { showPicker = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Icon(Icons.Filled.DateRange, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.size(8.dp))
                    Text(formatDate(state.dateEpochDay), style = MaterialTheme.typography.titleMedium)
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                ) {
                    Text(stringResource(R.string.add_cancel))
                }
                Button(
                    onClick = { viewModel.save(onDone = onBack) },
                    enabled = state.canSave,
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                ) {
                    Text(stringResource(R.string.add_save))
                }
            }
        }
    }

    if (showPicker) {
        val todayMillis = LocalDate.now().toEpochDay() * DAY_MS
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = state.dateEpochDay * DAY_MS,
            selectableDates = object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long): Boolean =
                    utcTimeMillis <= todayMillis
            }
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let {
                        viewModel.selectDate(Math.floorDiv(it, DAY_MS))
                    }
                    showPicker = false
                }) {
                    Text(stringResource(R.string.common_save))
                }
            },
            dismissButton = {
                TextButton(onClick = { showPicker = false }) {
                    Text(stringResource(R.string.add_cancel))
                }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }
}
