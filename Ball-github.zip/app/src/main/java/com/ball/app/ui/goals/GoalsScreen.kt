package com.ball.app.ui.goals

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ball.app.R
import com.ball.app.data.local.entity.SubjectEntity
import com.ball.app.ui.common.BallCard
import com.ball.app.ui.common.ScreenHeader
import com.ball.app.ui.common.formatNumber
import com.ball.app.ui.common.pluralString
import com.ball.app.ui.theme.Green
import com.ball.app.ui.theme.TextMuted
import kotlin.math.roundToInt

@Composable
fun GoalsScreen(viewModel: GoalsViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        ScreenHeader(title = stringResource(R.string.goals_title))
        Spacer(Modifier.height(8.dp))

        if (state.items.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.goals_empty),
                    style = MaterialTheme.typography.titleMedium,
                    color = TextMuted
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(state.items, key = { it.goal.id }) { item ->
                    BallCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.subjectName,
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    text = stringResource(
                                        R.string.goals_target,
                                        formatNumber(item.goal.target, 1)
                                    ),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            IconButton(onClick = { viewModel.deleteGoal(item.goal) }) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = stringResource(R.string.goals_delete),
                                    tint = TextMuted
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { item.progress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.outlineVariant
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = stringResource(R.string.goals_progress, item.progress),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted
                        )
                        Spacer(Modifier.height(4.dp))
                        val needed = item.fivesNeeded
                        when (needed) {
                            null -> Text(
                                text = stringResource(R.string.goals_unreachable),
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextMuted
                            )
                            0 -> Text(
                                text = stringResource(R.string.goals_reached),
                                style = MaterialTheme.typography.bodyLarge,
                                color = Green
                            )
                            else -> Text(
                                text = pluralString(R.plurals.goals_hint, needed),
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { showAdd = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(22.dp))
            Spacer(Modifier.size(8.dp))
            Text(stringResource(R.string.goals_add), style = MaterialTheme.typography.labelLarge)
        }
    }

    if (showAdd) {
        AddGoalDialog(
            subjects = state.subjects,
            onDismiss = { showAdd = false },
            onConfirm = { subjectId, target ->
                viewModel.addGoal(subjectId, target)
                showAdd = false
            }
        )
    }
}

@Composable
private fun AddGoalDialog(
    subjects: List<SubjectEntity>,
    onDismiss: () -> Unit,
    onConfirm: (Long, Double) -> Unit
) {
    var selected by remember { mutableStateOf(subjects.firstOrNull()?.id) }
    var target by remember { mutableFloatStateOf(4.5f) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.goals_add)) },
        text = {
            if (subjects.isEmpty()) {
                Text(stringResource(R.string.add_need_subject))
            } else {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = stringResource(R.string.goals_pick_subject),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                    subjects.forEach { subject ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selected = subject.id },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selected == subject.id,
                                onClick = { selected = subject.id }
                            )
                            Text(text = subject.name, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = stringResource(
                            R.string.goals_target,
                            formatNumber(target.toDouble(), 1)
                        ),
                        style = MaterialTheme.typography.titleMedium
                    )
                    Slider(
                        value = target,
                        onValueChange = { target = it },
                        valueRange = 3f..5f,
                        steps = 19
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selected != null,
                onClick = {
                    selected?.let { onConfirm(it, (target * 10f).roundToInt() / 10.0) }
                }
            ) {
                Text(stringResource(R.string.common_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.add_cancel))
            }
        }
    )
}
