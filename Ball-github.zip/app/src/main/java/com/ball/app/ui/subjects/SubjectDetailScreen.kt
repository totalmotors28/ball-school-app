package com.ball.app.ui.subjects

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ball.app.R
import com.ball.app.ui.common.BallCard
import com.ball.app.ui.common.ScreenHeader
import com.ball.app.ui.common.formatDate
import com.ball.app.ui.common.formatNumber
import com.ball.app.ui.common.gradeColor
import com.ball.app.ui.common.kindLabel
import com.ball.app.ui.theme.Danger
import com.ball.app.ui.theme.TextMuted

@Composable
fun SubjectDetailScreen(
    subjectId: Long,
    onBack: () -> Unit,
    viewModel: SubjectsViewModel = viewModel()
) {
    val flow = remember(subjectId) { viewModel.detail(subjectId) }
    val state by flow.collectAsStateWithLifecycle<SubjectDetailState?>(initialValue = null)
    var showDelete by remember { mutableStateOf(false) }

    val detail = state
    val subject = detail?.subject
    if (detail == null || subject == null) {
        Box(Modifier.fillMaxSize())
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        ScreenHeader(title = subject.name, onBack = onBack)
        Spacer(Modifier.height(8.dp))

        BallCard {
            Text(
                text = stringResource(R.string.subjects_avg),
                style = MaterialTheme.typography.bodyLarge,
                color = TextMuted
            )
            Text(
                text = formatNumber(detail.average),
                fontSize = 44.sp,
                fontWeight = FontWeight.Bold,
                color = detail.average?.let { gradeColor(it) } ?: TextMuted
            )
            Text(
                text = stringResource(R.string.subjects_count, detail.grades.size),
                style = MaterialTheme.typography.bodyMedium,
                color = TextMuted
            )
        }
        Spacer(Modifier.height(12.dp))

        if (detail.grades.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.grades_empty),
                    style = MaterialTheme.typography.titleMedium,
                    color = TextMuted
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(detail.grades, key = { it.id }) { grade ->
                    BallCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = grade.value.toString(),
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold,
                                color = gradeColor(grade.value.toDouble())
                            )
                            Spacer(Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = kindLabel(grade.kind),
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = formatDate(grade.date),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextMuted
                                )
                            }
                            IconButton(onClick = { viewModel.deleteGrade(grade) }) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = stringResource(R.string.common_delete),
                                    tint = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = { showDelete = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Danger)
        ) {
            Text(stringResource(R.string.subjects_delete), style = MaterialTheme.typography.labelLarge)
        }
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text(stringResource(R.string.subjects_delete)) },
            text = { Text(stringResource(R.string.subjects_delete_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    showDelete = false
                    viewModel.deleteSubject(subject)
                    onBack()
                }) {
                    Text(stringResource(R.string.common_yes), color = Danger)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDelete = false }) {
                    Text(stringResource(R.string.common_no))
                }
            }
        )
    }
}
