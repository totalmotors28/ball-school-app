package com.ball.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import com.ball.app.ui.navigation.BallNavGraph
import com.ball.app.ui.theme.BallTheme

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BallTheme {
                BallNavGraph()
            }
        }
    }
}
