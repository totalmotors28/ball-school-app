package com.ball.app.ui.addgrade

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ball.app.BallApp
import com.ball.app.data.local.entity.GradeKinds
import com.ball.app.data.local.entity.SubjectEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

data class AddGradeUiState(
    val subjects: List<SubjectEntity> = emptyList(),
    val subjectId: Long? = null,
    val value: Int? = null,
    val kind: String = GradeKinds.HOMEWORK,
    val dateEpochDay: Long = LocalDate.now().toEpochDay(),
    val saving: Boolean = false
) {
    val canSave: Boolean get() = subjectId != null && value != null && !saving
}

private data class Form(
    val subjectId: Long? = null,
    val value: Int? = null,
    val kind: String = GradeKinds.HOMEWORK,
    val dateEpochDay: Long = LocalDate.now().toEpochDay(),
    val saving: Boolean = false
)

class AddGradeViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = (application as BallApp).repository
    private val form = MutableStateFlow(Form())

    val state: StateFlow<AddGradeUiState> = combine(repo.subjects, form) { subjects, f ->
        val selected = f.subjectId?.takeIf { id -> subjects.any { it.id == id } }
            ?: subjects.firstOrNull()?.id
        AddGradeUiState(
            subjects = subjects,
            subjectId = selected,
            value = f.value,
            kind = f.kind,
            dateEpochDay = f.dateEpochDay,
            saving = f.saving
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AddGradeUiState())

    fun selectSubject(id: Long) = form.update { it.copy(subjectId = id) }
    fun selectValue(value: Int) = form.update { it.copy(value = value) }
    fun selectKind(kind: String) = form.update { it.copy(kind = kind) }
    fun selectDate(epochDay: Long) = form.update { it.copy(dateEpochDay = epochDay) }

    fun save(onDone: () -> Unit) {
        val s = state.value
        val subjectId = s.subjectId ?: return
        val value = s.value ?: return
        if (s.saving) return
        form.update { it.copy(saving = true) }
        viewModelScope.launch {
            repo.addGrade(subjectId, value, s.kind, s.dateEpochDay)
            onDone()
        }
    }
}
