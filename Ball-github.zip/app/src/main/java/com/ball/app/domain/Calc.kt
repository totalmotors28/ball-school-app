package com.ball.app.domain

import com.ball.app.data.local.entity.GoalEntity
import com.ball.app.data.local.entity.GradeEntity
import com.ball.app.data.local.entity.StreakEntity
import com.ball.app.data.local.entity.SubjectEntity
import kotlin.math.ceil
import kotlin.math.roundToInt

data class SubjectStat(
    val subject: SubjectEntity,
    val average: Double?,
    val count: Int
)

data class GoalItem(
    val goal: GoalEntity,
    val subjectName: String,
    val current: Double?,
    val progress: Int,
    /** null = unreachable, 0 = already reached */
    val fivesNeeded: Int?
)

object Calc {

    fun average(grades: List<GradeEntity>): Double? =
        if (grades.isEmpty()) null else grades.sumOf { it.value }.toDouble() / grades.size

    fun averageBetween(grades: List<GradeEntity>, from: Long, to: Long): Double? =
        average(grades.filter { it.date in from..to })

    /** Average of the last 7 days minus average of the previous 7 days. */
    fun trend(grades: List<GradeEntity>, today: Long): Double {
        val last = averageBetween(grades, today - 6, today)
        val previous = averageBetween(grades, today - 13, today - 7)
        return if (last == null || previous == null) 0.0 else last - previous
    }

    /** 0.6 * overall average + 0.4 * average over the last 14 days. */
    fun forecast(grades: List<GradeEntity>, today: Long): Double? {
        val overall = average(grades) ?: return null
        val recent = averageBetween(grades, today - 13, today) ?: overall
        return 0.6 * overall + 0.4 * recent
    }

    /** ((current - start) / (target - start)) * 100, clamped to 0..100. */
    fun goalProgress(current: Double?, start: Double, target: Double): Int {
        if (current == null) return 0
        val denominator = target - start
        if (denominator <= 0.0) return if (current >= target) 100 else 0
        return (((current - start) / denominator) * 100.0).coerceIn(0.0, 100.0).roundToInt()
    }

    /**
     * Minimal N such that (sum + N * 5) / (count + N) >= target.
     * Returns 0 if already reached, null if it can never be reached.
     */
    fun fivesNeeded(sum: Int, count: Int, target: Double): Int? {
        if (count == 0) return if (target <= 5.0) 1 else null

        fun ok(n: Int): Boolean = (sum + 5.0 * n) >= target * (count + n) - 1e-9

        if (ok(0)) return 0
        if (target >= 5.0 - 1e-9) return null

        var n = ceil((target * count - sum) / (5.0 - target)).toInt().coerceAtLeast(1)
        while (n > 1 && ok(n - 1)) n--
        while (!ok(n)) n++
        return n
    }

    fun subjectStats(subjects: List<SubjectEntity>, grades: List<GradeEntity>): List<SubjectStat> {
        val bySubject = grades.groupBy { it.subjectId }
        return subjects.map { subject ->
            val list = bySubject[subject.id].orEmpty()
            SubjectStat(subject, average(list), list.size)
        }
    }

    fun goalItems(
        goals: List<GoalEntity>,
        subjects: List<SubjectEntity>,
        grades: List<GradeEntity>
    ): List<GoalItem> {
        val subjectsById = subjects.associateBy { it.id }
        val bySubject = grades.groupBy { it.subjectId }
        return goals.mapNotNull { goal ->
            val subject = subjectsById[goal.subjectId] ?: return@mapNotNull null
            val list = bySubject[goal.subjectId].orEmpty()
            val current = average(list)
            GoalItem(
                goal = goal,
                subjectName = subject.name,
                current = current,
                progress = goalProgress(current, goal.startAverage, goal.target),
                fivesNeeded = fivesNeeded(list.sumOf { it.value }, list.size, goal.target)
            )
        }
    }

    /**
     * Streak: today + yesterday -> count + 1; gap > 1 day -> 1; same date -> unchanged.
     */
    fun streakNext(previous: StreakEntity?, today: Long): StreakEntity = when {
        previous == null -> StreakEntity(id = 1, lastEntryDate = today, count = 1)
        previous.lastEntryDate == today -> previous
        today - previous.lastEntryDate == 1L ->
            StreakEntity(id = 1, lastEntryDate = today, count = previous.count + 1)
        else -> StreakEntity(id = 1, lastEntryDate = today, count = 1)
    }

    /** Streak shown on screen: a broken streak (gap > 1 day) is displayed as 0. */
    fun effectiveStreak(streak: StreakEntity?, today: Long): Int =
        if (streak == null) 0 else if (today - streak.lastEntryDate <= 1L) streak.count else 0
}
