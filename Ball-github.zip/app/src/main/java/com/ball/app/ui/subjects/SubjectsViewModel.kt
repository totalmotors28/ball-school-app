package com.ball.app.ui.subjects

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ball.app.BallApp
import com.ball.app.data.local.entity.GradeEntity
import com.ball.app.data.local.entity.SubjectEntity
import com.ball.app.domain.Calc
import com.ball.app.domain.SubjectStat
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SubjectDetailState(
    val subject: SubjectEntity?,
    val grades: List<GradeEntity>,
    val average: Double?
)

class SubjectsViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = (application as BallApp).repository

    val stats: StateFlow<List<SubjectStat>> = combine(repo.subjects, repo.grades) { subjects, grades ->
        Calc.subjectStats(subjects, grades)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun detail(subjectId: Long): Flow<SubjectDetailState> =
        combine(repo.subject(subjectId), repo.gradesBySubject(subjectId)) { subject, grades ->
            SubjectDetailState(subject, grades, Calc.average(grades))
        }

    fun addSubject(name: String) {
        viewModelScope.launch { repo.addSubject(name) }
    }

    fun deleteSubject(subject: SubjectEntity) {
        viewModelScope.launch { repo.deleteSubject(subject) }
    }

    fun deleteGrade(grade: GradeEntity) {
        viewModelScope.launch { repo.deleteGrade(grade) }
    }
}
