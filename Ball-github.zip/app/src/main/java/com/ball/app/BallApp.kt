package com.ball.app

import android.app.Application
import com.ball.app.data.local.AppDatabase
import com.ball.app.data.prefs.ProfilePrefs
import com.ball.app.data.repository.BallRepository

class BallApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.get(this) }
    val repository: BallRepository by lazy { BallRepository(database, ProfilePrefs(this)) }
}
